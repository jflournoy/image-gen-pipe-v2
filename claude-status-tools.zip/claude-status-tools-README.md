# Claude Status Management Tools

This package adds `/continue` and `/condense` skills to your Claude Code project for efficient `.claude-current-status` file management.

## What's Included

### 1. **`/continue` Skill**
- **Purpose**: Efficiently resume work by extracting recent session context
- **Usage**: `/continue` - shows most recent session from `.claude-current-status`
- **Features**: Smart extraction, skips archive notes, multiple fallback strategies

### 2. **`/condense` Skill**
- **Purpose**: Archive old content, keep recent work manageable
- **Usage**:
  - `/condense` - keep last 200 lines (default)
  - `/condense 300` - keep last 300 lines
  - `/condense 150` - keep last 150 lines
- **Features**: Archives to `.claude-archive/`, preserves recent work

### 3. **Helper Scripts**
- `scripts/status-helper.sh` - Auto-cleanup helper functions
- `scripts/update-status-example.sh` - Example usage pattern

## Installation

### Quick Install (Unix/macOS/Linux)
```bash
# 1. Download and unzip to your project root
unzip claude-status-tools.zip

# 2. Make scripts executable
chmod +x scripts/*.sh

# 3. Update your CLAUDE.md (add this section to State Tracking)
echo '
**New Status Management Commands:**
- `/continue` - Efficiently resume work by extracting recent session context
- `/condense [N]` - Archive old content, keep last N lines (default: 200)
- `scripts/status-helper.sh` - Auto-cleanup helper for updates

**Auto-Cleanup Pattern:** When updating `.claude-current-status`, check if file exceeds 300 lines and consider running `/condense`.
' >> CLAUDE.md

# 4. Update .claude/commands/README.md commands list
# Add these lines to the commands list:
# - `condense` - Condense .claude-current-status by archiving old content
# - `continue` - Efficiently resume work by extracting recent session
```

### Manual Install
1. Copy `.claude/commands/continue.md` to your project's `.claude/commands/`
2. Copy `.claude/commands/condense.md` to your project's `.claude/commands/`
3. Copy `scripts/` directory to your project root
4. Make scripts executable: `chmod +x scripts/*.sh`
5. Update documentation (see below)

## Documentation Updates

### Update CLAUDE.md
Add this to the "State Tracking" section of your `CLAUDE.md`:

```markdown
**New Status Management Commands:**
- `/continue` - Efficiently resume work by extracting recent session context
- `/condense [N]` - Archive old content, keep last N lines (default: 200)
- `scripts/status-helper.sh` - Auto-cleanup helper for updates

**Auto-Cleanup Pattern:** When updating `.claude-current-status`, check if file exceeds 300 lines and consider running `/condense`.
```

### Update .claude/commands/README.md
Add these lines to your commands list:
```markdown
- `condense` - Condense .claude-current-status by archiving old content
- `continue` - Efficiently resume work by extracting recent session
```

## Usage Examples

### Basic Workflow
```bash
# 1. Resume work after context limits
/continue

# 2. Work and update status file
echo "## My Update ($(date))" >> .claude-current-status
echo "Working on feature X..." >> .claude-current-status

# 3. Check file size
scripts/status-helper.sh summary

# 4. Condense if file gets large (>300 lines)
/condense 250
```

### Using Helper Script
```bash
# Add entry with auto-cleanup check
scripts/status-helper.sh add "Completed feature implementation" "Feature"

# Check if file needs condensation
scripts/status-helper.sh check

# Show recent entries
scripts/status-helper.sh recent 10

# Get file summary
scripts/status-helper.sh summary
```

## Auto-Cleanup Integration

For automatic cleanup during updates, use this pattern:

```bash
# In your update scripts
if [ -f .claude-current-status ] && [ $(wc -l < .claude-current-status) -gt 300 ]; then
    echo "⚠️ Status file large, consider: /condense 200"
fi
```

Or use the helper function:
```bash
# Source the helper script
source scripts/status-helper.sh

# This will warn if file > 300 lines
add_status_entry "My update text" "Update Section"
```

## File Structure After Installation
```
your-project/
├── .claude/
│   └── commands/
│       ├── continue.md      # /continue skill
│       └── condense.md      # /condense skill
├── scripts/
│   ├── status-helper.sh     # Auto-cleanup helper
│   └── update-status-example.sh  # Usage example
├── CLAUDE.md                # Updated with new commands
└── .claude-current-status   # Your status file
```

## How It Works

### `/continue` Logic
1. Finds last `## Session Resume` or `## Session Start` heading
2. If not found, finds any `##` heading (skips archive notes)
3. Falls back to showing last 150 lines
4. Extracts only recent content (not entire file)

### `/condense` Logic
1. Checks current file size
2. Archives lines beyond keep limit to `.claude-archive/`
3. Creates new file with archive note + recent work
4. Preserves file structure

### Auto-Cleanup
- Default limit: 300 lines
- Configurable in `scripts/status-helper.sh`
- Warns when file exceeds limit

## Customization

### Change Auto-Condense Limit
Edit `scripts/status-helper.sh`:
```bash
AUTO_CONDENSE_LIMIT=400  # Change from 300 to 400
```

### Change Default Keep Lines
Edit `.claude/commands/condense.md`:
```bash
KEEP_LINES="${1:-250}"  # Change from 200 to 250
```

## Troubleshooting

### Skills Not Showing Up
- Ensure files are in `.claude/commands/` directory
- Check file permissions: `ls -la .claude/commands/`
- Restart Claude Code session

### Script Permission Errors
```bash
chmod +x scripts/*.sh
```

### Archive Directory Not Created
```bash
mkdir -p .claude-archive
```

## License
MIT - Free to use and modify

## Created By
Claude Code Status Management System
Part of PhD Unemployment Model Project